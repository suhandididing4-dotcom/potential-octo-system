# DSPMixerAndroid

Aplikasi DSP audio Android sederhana dengan:
- 10-band equalizer
- Bass Boost
- Virtualizer
- Preset Flat, Bass Boost, Vocal, Rock, Pop
- Preamp, balance, reset
- GitHub Actions untuk build APK

## Build lokal

```bash
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

Upload seluruh isi proyek ke repository GitHub, commit ke branch `main`, lalu buka:
Actions -> Build DSP Mixer APK.

Artifact `DSPMixer-debug` berisi APK.
