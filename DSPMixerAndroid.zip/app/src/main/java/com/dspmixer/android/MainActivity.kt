package com.dspmixer.android

import android.media.audiofx.Equalizer
import android.media.audiofx.BassBoost
import android.media.audiofx.Virtualizer
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private val bands = ArrayList<SeekBar>()

    private val frequencies = arrayOf(
        "31 Hz", "62 Hz", "125 Hz", "250 Hz", "500 Hz",
        "1 kHz", "2 kHz", "4 kHz", "8 kHz", "16 kHz"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupEffects()
        setupUi()
    }

    private fun setupEffects() {
        try {
            equalizer = Equalizer(0, 0).apply {
                enabled = true
            }
            bassBoost = BassBoost(0, 0).apply {
                enabled = true
            }
            virtualizer = Virtualizer(0, 0).apply {
                enabled = true
            }
        } catch (e: Exception) {
            Toast.makeText(this, "DSP tidak didukung perangkat ini", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupUi() {
        val switch = findViewById<Switch>(R.id.dspSwitch)
        val status = findViewById<TextView>(R.id.statusText)
        val preset = findViewById<Spinner>(R.id.presetSpinner)
        val preamp = findViewById<SeekBar>(R.id.preampBar)
        val bass = findViewById<SeekBar>(R.id.bassBar)
        val treble = findViewById<SeekBar>(R.id.trebleBar)
        val balance = findViewById<SeekBar>(R.id.balanceBar)
        val reset = findViewById<Button>(R.id.resetButton)
        val container = findViewById<LinearLayout>(R.id.equalizerContainer)

        val presets = arrayOf("Flat", "Bass Boost", "Vocal", "Rock", "Pop")
        preset.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presets)

        for (i in frequencies.indices) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            val label = TextView(this).apply {
                text = frequencies[i]
                setTextColor(0xFFFFFFFF.toInt())
                layoutParams = LinearLayout.LayoutParams(70, 50)
            }
            val bar = SeekBar(this).apply {
                max = 240
                progress = 120
                layoutParams = LinearLayout.LayoutParams(0, 50, 1f)
            }
            bands.add(bar)
            row.addView(label)
            row.addView(bar)
            container.addView(row)

            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    setBand(i, p - 120)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        switch.setOnCheckedChangeListener { _, enabled ->
            equalizer?.enabled = enabled
            bassBoost?.enabled = enabled
            virtualizer?.enabled = enabled
            status.text = if (enabled) "DSP aktif" else "DSP mati"
        }

        preset.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                applyPreset(position)
            }
        }

        preamp.setOnSeekBarChangeListener(simpleListener { p ->
            findViewById<TextView>(R.id.preampLabel).text = "Preamp: ${(p - 120) / 10f} dB"
        })

        bass.setOnSeekBarChangeListener(simpleListener { p ->
            val v = p - 50
            findViewById<TextView>(R.id.bassLabel).text = "Bass: $v%"
            try { bassBoost?.setStrength((p * 1000 / 100).toShort()) } catch (_: Exception) {}
        })

        treble.setOnSeekBarChangeListener(simpleListener { p ->
            findViewById<TextView>(R.id.trebleLabel).text = "Treble: ${p - 50}%"
        })

        balance.setOnSeekBarChangeListener(simpleListener { p ->
            findViewById<TextView>(R.id.balanceLabel).text =
                when {
                    p < 95 -> "Balance: L ${100 - p}%"
                    p > 105 -> "Balance: R ${p - 100}%"
                    else -> "Balance: Center"
                }
        })

        reset.setOnClickListener {
            preamp.progress = 120
            bass.progress = 50
            treble.progress = 50
            balance.progress = 100
            bands.forEach { it.progress = 120 }
            preset.setSelection(0)
        }
    }

    private fun simpleListener(action: (Int) -> Unit) =
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) action(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }

    private fun setBand(index: Int, millibel: Int) {
        try {
            val eq = equalizer ?: return
            if (index < eq.numberOfBands) {
                val min = eq.bandLevelRange[0].toInt()
                val max = eq.bandLevelRange[1].toInt()
                val value = millibel.coerceIn(min, max).toShort()
                eq.setBandLevel(index.toShort(), value)
            }
        } catch (_: Exception) {}
    }

    private fun applyPreset(position: Int) {
        val values = when (position) {
            1 -> intArrayOf(80, 70, 55, 35, 10, 0, -10, -10, -5, 0)
            2 -> intArrayOf(-20, -10, 0, 10, 20, 35, 45, 35, 20, 10)
            3 -> intArrayOf(50, 35, 10, -5, -10, 10, 25, 35, 30, 20)
            4 -> intArrayOf(45, 30, 10, 0, 10, 20, 25, 20, 15, 10)
            else -> IntArray(10)
        }
        bands.forEachIndexed { i, bar ->
            val v = values[i].coerceIn(-100, 100)
            bar.progress = 120 + v
            setBand(i, v)
        }
    }

    override fun onDestroy() {
        equalizer?.release()
        bassBoost?.release()
        virtualizer?.release()
        super.onDestroy()
    }
}
